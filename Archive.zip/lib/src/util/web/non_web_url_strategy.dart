void configureWebUrl() {
  // No-op.
}
